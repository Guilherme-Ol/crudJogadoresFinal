<?php

class Calculadora
{
    public function somar()
    {
        $a = $_GET['a'] ?? 0;
        $b = $_GET['b'] ?? 0;
        return $a + $b;
    }

    public function subtrair()
    {
        $a = $_GET['a'] ?? 0;
        $b = $_GET['b'] ?? 0;
        return $a - $b;
    }

    public function multiplicar()
    {
        $a = $_GET['a'] ?? 0;
        $b = $_GET['b'] ?? 0;
        return $a * $b;
    }

    public function dividir()
    {   
        $a = $_GET['a'] ?? 0;
        $b = $_GET['b'] ?? 0;
        if ($b == 0) {
            return "Erro: Divisão por zero!";
        }
        return $a / $b;
    }
}