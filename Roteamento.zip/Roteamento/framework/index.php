<?php
require_once "Router.php";
require_once "Calculadora.php";
require_once "ObjetoMensagem.php";
$router = new Router();
$router->add("somar", "Calculadora", "somar");
$router->add("subtrair", "Calculadora", "subtrair");
$router->add("multiplicar", "Calculadora", "multiplicar");
$router->add("dividir", "Calculadora", "dividir");
$router->run();