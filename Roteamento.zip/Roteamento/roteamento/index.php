<?php
require_once("Calculadora.php");
require_once("ObjetoMensagem.php");
$url = $_GET["url"];
switch ($url) {
    case "somar":
        $calc = new Calculadora();
        $a = $_GET['a'] ?? 0;
        $b = $_GET['b'] ?? 0;
        echo "<h1>Resultado da soma de $a e $b: " . $calc->somar($a, $b) . "</h1>";
        break;

    case "subtrair":
        $calc = new Calculadora();
        $a = $_GET['a'] ?? 0;
        $b = $_GET['b'] ?? 0;
        echo "<h1>Resultado da subtração de $a e $b: " . $calc->subtrair($a, $b) . "</h1>";
        break;
}
