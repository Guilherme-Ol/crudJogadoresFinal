<?php

// ini_set('display_errors', 1);
// error_reporting(E_ALL);

//require_once(__DIR__ . "/../../dao/JogadorDAO.php");
require_once(__DIR__ . "/../../controller/JogadorController.php");

$msgErro = "";
$jogador = null;

$jogadorCont = new JogadorController();

if (isset($_POST['nome'])) {
    $id = $_POST["id"];
    $nome = trim($_POST['nome']) ? trim($_POST['nome']) : NULL;
    $idade = is_numeric($_POST['idade']) ? $_POST['idade'] : NULL;
    $posicao = trim($_POST['posicao']) ? trim($_POST['posicao']) : NULL;
    $idNacionalidade = is_numeric($_POST['nacionalidade']) ? $_POST['nacionalidade'] : NULL;
    $idClube = is_numeric($_POST['clube']) ? $_POST['clube'] : NULL;

    $jogador = new Jogador();
    $jogador->setId($id);
    $jogador->setNome($nome);
    $jogador->setIdade($idade);
    $jogador->setPosicao($posicao);

    $nacionalidade = new Nacionalidade();
    $nacionalidade->setId($idNacionalidade);
    $jogador->setNacionalidade($nacionalidade);

    $clube = new Clube();
    $clube->setId($idClube);
    $jogador->setClube($clube);
    $erros = $jogadorCont->alterar($jogador);

    if(empty($erros))
        header("Location: listar.php");
    else
        $msgErro = implode("<br>", $erros);
    // print_r($jogador);
    // $jogadorCont = new JogadorController();
    // $erros = $jogadorCont->alterar($jogador);

} else {


    //carregar os dados do jogador a ser alterado
    $id = 0;
    if (isset($_GET['id']))
        $id = $_GET['id'];


    $jogadorCont = new JogadorController();
    $jogador = $jogadorCont->buscarPorId($id);
    if (! $jogador) {
        echo "ID do jogador invalido!<br>";
        echo "<a href='listar.php'>Voltar</a>";
        exit;
    }
}

// print_r($jogador);

require_once(__DIR__ . "/form.php");
