<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once(__DIR__ . "/../include/header.php");
require_once(__DIR__ . "/../include/menu.php");

?>

<div class="container py-5">

    <div class="text-center mb-5">
        <h2>Sobre o nosso site</h2>
    </div>
    <div class="row align-items-center mb-5">

        <div class="col-md-6 text-center">
            <img src="<?= BASE_URL ?>/img/vitin.png" style="width: 60%; height: auto;">
        </div>

        <div class="col-md-6">
    <h3>Sobre o projeto</h3>

    <p>
        Nosso site foi desenvolvido por <strong>Victor e Guilherme</strong>
        com o objetivo de realizar o cadastro e gerenciamento de jogadores
        de futebol. É possível cadastrar informações como nome, nacionalidade,
        clube, idade e posição do jogador.
    </p>

    <p>
        Durante o desenvolvimento, utilizamos tecnologias como
        <strong>PHP, HTML, CSS e Bootstrap</strong> para criar
        uma página responsiva e agradável para os usuários.
    </p>

    <p>
        Após o preenchimento dos dados, o sistema realiza o cadastro e
        apresenta uma confirmação informando que o jogador foi cadastrado
        com sucesso. O projeto também foi desenvolvido em equipe, permitindo
        que Victor e Guilherme contribuíssem com ideias e funcionalidades
        para melhorar o resultado final.
    </p>
</div>

</div>

    </div>

    <!-- Desenvolvedores -->
    <div class="text-center mt-5">

        <h3>Desenvolvedores</h3>

        <p class="text-muted mb-4">
            Confira os GitHubs dos integrantes responsáveis pelo projeto.
        </p>

        <a 
            href="https://github.com/Guilherme-Ol" 
            target="_blank"
            class="btn btn-secondary me-2"
        >
            GitHub de Guilherme
        </a>

        <a 
            href="https://github.com/victor-lang9" 
            target="_blank"
            class="btn btn-secondary"
        >
            GitHub de Victor
        </a>

    </div>

</div>

<?php

require_once(__DIR__ . "/../include/footer.php");

?>
