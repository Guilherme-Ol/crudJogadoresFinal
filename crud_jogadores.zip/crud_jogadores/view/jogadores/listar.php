<?php

//Mostrar erros do PHP
ini_set('display_errors', 1);
error_reporting(E_ALL);

//Teste da conexão com o banco de dados
//require_once(__DIR__ . "/../../util/Connection.php");
//$conn = Connection::getConnection();
//print_r($conn);

require_once(__DIR__ . "/../../controller/JogadorController.php");

//Buscar os jogadores -> origem: base de dados
$jogadorCont = new JogadorController();
$jogadores = $jogadorCont->listar();
//print_r($jogadores);

//Inclui o cabeçalho da página
require_once(__DIR__ . "/../include/header.php");
require_once(__DIR__ . "/../include/menu.php");
?>


<h3 class="text-center">Listagem de jogadores</h3>

<a href="inserir.php" class="btn btn-secondary mt-3">Inserir</a>

<table class="table table-striped mt-3">
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Idade</th>
        <th>Posição</th>
        <th>Nacionalidade</th>
        <th>Clube</th>
        <th>Excluir</th>
        <th>Alterar</th>
    </tr>

    <?php foreach($jogadores as $j): ?>
        <tr>
            <td><?= $j->getId() ?></td>
            <td><?= $j->getNome() ?></td>
            <td><?= $j->getIdade() ?></td>
            <td><?= $j->getPosicao() ?></td>
            <td><?= $j->getNacionalidade()->getNome() ?></td>
            <td><?= $j->getClube()->getNome() ?></td>
            <td>
            <a href="excluir.php?id=<?= $j->getId() ?>"
            onclick="if(!confirm('Confirma a exclusão?')) return false;">
            
                <img src="../../img/btn_excluir.png" alt="">
            </a>
        </td>
        <td>
        <a href="alterar.php?id=<?= $j->getId() ?>">
            
                <img src="../../img/btn_editar.png" alt="">
</a>
        </td>
        </tr>
    <?php endforeach; ?>
    

</table>


<?php
//Inclui o rodapé da página
require_once(__DIR__ . "/../include/footer.php");
?>

    
