<?php

require_once(__DIR__ . "/../../model/Jogador.php");
require_once(__DIR__ . "/../../model/Clube.php");
require_once(__DIR__ . "/../../model/Nacionalidade.php");
require_once(__DIR__ . "/../../controller/JogadorController.php");

$msgErro = "";
$jogador = null;

//Verificação: formulário já foi submetido?
if(isset($_POST['nome'])) {
    //1- Capturar os dados preenchidos no formulário
    $nome = trim($_POST['nome']) ? trim($_POST['nome']) : NULL;
    $idade = is_numeric($_POST['idade']) ? $_POST['idade'] : NULL;
    $idNacionalidade = is_numeric($_POST['nacionalidade']) ? $_POST['nacionalidade'] : NULL;
    $posicao = trim($_POST['posicao']) ? trim($_POST['posicao']) : NULL;
    $idClube = is_numeric($_POST['clube']) ? $_POST['clube'] : NULL;  

    //2- Criar um objeto Jogador para persistí-lo
    $jogador = new Jogador();
    $jogador->setId(0); 
    $jogador->setNome($nome);
    $jogador->setIdade($idade);
    $jogador->setPosicao($posicao);

    $nacionalidade = new Nacionalidade();
    $nacionalidade->setId($idNacionalidade);
    $jogador->setNacionalidade($nacionalidade);

    $clube = new Clube();
    $clube->setId($idClube);
    $jogador->setClube($clube);

    //3- Validar os dados
    //4- Persistir o objeto
    $jogadorCont = new JogadorController();
    $erros = $jogadorCont->inserir($jogador);

    if(empty($erros)) 
        header("location: listar.php");
    else
        $msgErro = implode("<br>", $erros);
}

require_once(__DIR__ . "/form.php");
?>