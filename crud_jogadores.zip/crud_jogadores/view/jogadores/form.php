<?php

require_once(__DIR__ . "/../../controller/ClubeController.php");
require_once(__DIR__ . "/../../controller/NacionalidadeController.php");



$clubeCont = new ClubeController();
$clubes = $clubeCont->listar();
//print_r($cursos);

$nacionalidadeCont = new NacionalidadeController();
$nacionalidades = $nacionalidadeCont->listar();
//print_r($nacionalidades);

require_once(__DIR__ . "/../include/header.php");
require_once(__DIR__ . "/../include/menu.php");
?>

<h3 class="text-center"><?= $jogador && $jogador->getId() ? "Alterar" : "Inserir" ?> Jogador</h3>

<div class="row">

    <div class="col-6">
        <form action="" method="POST">

            <div>
                <label for="txtNome" class="form-label h4"> Nome: </label>
                <input type="text" id="txtNome" name="nome"
                    placeholder="Informe o nome" class="form-control"
                    value="<?= $jogador ? $jogador->getNome() : '' ?>">
            </div>

            <div>
                <label for="txtIdade" class="form-label h4">Idade: </label>
                <input type="number" id="txtIdade" name="idade"
                    placeholder="Informe a idade" class="form-control"
                    value="<?= $jogador ? $jogador->getIdade() : '' ?>">
            </div>

            <div>
                <label for="txtPosicao" class="form-label h4">Posição: </label>
                <select class="form-select form-select-lg mb-3 h4" name="posicao" id="selPosicao">
                    <option value="">----Selecione-----</option>
                    <option value="Goleiro" <?= $jogador && $jogador->getPosicao() == "Goleiro" ? 'selected' : '' ?>>GOL</option>
                    <option value="Zagueiro" <?= $jogador && $jogador->getPosicao() == "Zagueiro" ? 'selected' : '' ?>>ZAG</option>
                    <option value="Lateral-Direita" <?= $jogador && $jogador->getPosicao() == "Lateral-Direito" ? 'selected' : '' ?>>LD</option>
                    <option value="Lateral-Esquerda" <?= $jogador && $jogador->getPosicao() == "Lateral-Esquerda" ? 'selected' : '' ?>>LE</option>  
                    <option value="Meio-campo" <?= $jogador && $jogador->getPosicao() == "Meio-campo" ? 'selected' : '' ?>>MEI</option>
                    <option value="Meia-Atacante" <?= $jogador && $jogador->getPosicao() == "Meia-Atacante" ? 'selected' : '' ?>>MAT</option>
                    <option value="Ponta-Esquerda" <?= $jogador && $jogador->getPosicao() == "Ponta-Esquerda" ? 'selected' : '' ?>>PTE</option>
                    <option value="Ponta-Direita" <?= $jogador && $jogador->getPosicao() == "Ponta-Direita" ? 'selected' : '' ?>>PTD</option>
                    <option value="Atacante" <?= $jogador && $jogador->getPosicao() == "Atacante" ? 'selected' : '' ?>>ATA</option>
                </select>
            </div>

            <div>
                <label class="form-label h4" for="selNacionalidade">Nacionalidade: </label>
                <select class="form-select form-select-lg mb-3 h4" name="nacionalidade" id="selNacionalidade">
                    <option value="">----Selecione-----</option>

                    <!-- Nacionalidades criadas de forma dinâmica -->
                    <?php foreach ($nacionalidades as $n): ?>
                        <option value="<?= $n->getId() ?>"
                            <?php
                            if ($jogador && $jogador->getNacionalidade()->getId() == $n->getId())           //com foreach
                                echo "selected";
                            ?>>
                            <?= $n->getNome() ?></option>
                    <?php endforeach; ?>

                </select>
            </div>
            

            <div>
                <label class="form-label h4" for="selClube">Clube: </label>
                <select class="form-select form-select-lg mb-3 h4" name="clube" id="selClube">
                    <option value="">----Selecione-----</option>

                    <!-- Clubes criados de forma dinâmica -->
                    <?php foreach ($clubes as $c): ?>
                        <option value="<?= $c->getId() ?>"
                            <?php
                            if ($jogador && $jogador->getClube()->getId() == $c->getId())           //com foreach
                                echo "selected";
                            ?>>
                            <?= $c->getNome() ?></option>
                    <?php endforeach; ?>

                </select>
            </div>
            <div>
                <input type="hidden" name="id" value="<?= $jogador ? $jogador->getId() : 0 ?>">

            </div>
            <div>
                <button class="btn btn-primary" type="submit">Gravar</button>
            </div>
        </form>
    </div>

    <div class="col-6">
        <?php if ($msgErro): ?>
            <div class="alert alert-danger">
                <?= $msgErro ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<a class="btn btn-secondary" href="listar.php">Voltar</a>

<?php
require_once(__DIR__ . "/../include/footer.php");
?>