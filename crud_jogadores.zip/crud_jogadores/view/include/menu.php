<?php
require_once(__DIR__ . "/../../util/config.php");
?>

<nav class="navbar navbar-expand-md btn btn-secondary px-3">
    <a class="navbar-brand" href="<?= BASE_URL ?>">Cadastro de jogadores</a>
    <button class="navbar-toggler" type="button"
        data-bs-toggle="collapse" data-bs-target="#navSite">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navSite">
    </div>
    <ul class="navbar-nav ms-auto">
        <li class="nav-item">
            <a class="nav-link" href="<?= BASE_URL ?>">Home</a>
        </li>

        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#"
                id="navDropDown" data-bs-toggle="dropdown">Cadastros</a>
            <div class="dropdown-menu btn btn-secondary">
                <a class="dropdown-item" href="<?= BASE_URL ?>/view/jogadores/listar.php">Jogadores</a>
                <a class="dropdown-item" href="<?= BASE_URL ?>/view/clubes/informacao.php">Clubes</a>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?= BASE_URL ?>/view/jogadores/sobre.php">Sobre</a>
        </li>
    </ul>
</nav>