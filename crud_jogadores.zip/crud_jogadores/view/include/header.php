<?php
require_once(__DIR__ . "/../../util/config.php");
?>


<html lang="pt-br">

<head>
    <link rel="icon" type="image/webp" href="<?= BASE_URL ?>/img/bola.webp">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cadastro de jogadores</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
</head>

<body>
<!-- Classe container do bootstrap -->
<div class="container">