<!-- Fechamento da tag aberta no header -->
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  </body>
  <!-- Footer -->
<footer class="bg-light text-muted mt-3">
 <div class="text-center p-4">
 © 2026 Copyright:
 <a href=""
target="blank"></a>
 </div>
</footer>
</html>