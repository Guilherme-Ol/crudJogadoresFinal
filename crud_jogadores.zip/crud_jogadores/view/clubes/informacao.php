<?php

//Mostrar erros do PHP
ini_set('display_errors', 1);
error_reporting(E_ALL);

//Teste da conexão com o banco de dados
//require_once(__DIR__ . "/../../util/Connection.php");
//$conn = Connection::getConnection();
//print_r($conn);

require_once(__DIR__ . "/../../controller/JogadorController.php");

//Buscar os jogadores -> origem: base de dados
$jogadorCont = new JogadorController();
$jogadores = $jogadorCont->listar();
//print_r($jogadores);

//Inclui o cabeçalho da página
require_once(__DIR__ . "/../include/header.php");
require_once(__DIR__ . "/../include/menu.php");
?>
<table class="table table-striped mt-3">
    <tr>
        
        <th>Clubes com Jogadores</th>
        <th>Atletas</th>
        
    </tr>

    <?php foreach($jogadores as $j): ?>
        <tr>
            <td><?= $j->getClube()->getNome() ?></td>
            <td><?= $j->getNome() ?></td>
        </tr>
    <?php endforeach; ?>
    

</table>







<?php  
echo "Em manutenção!";
require_once(__DIR__ . "/../include/footer.php");
?>
