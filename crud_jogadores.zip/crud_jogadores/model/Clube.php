<?php

class Clube {
    
    //Atributos
    private ?int $id;
    private ?string $nome;
    private ?string $abreviacao;
    private ?string $imagem;

    //GETs e SETs
    
    /**
     * Get the value of id
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     */
    public function setId(?int $id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of nome
     */
    public function getNome(): ?string
    {
        return $this->nome;
    }

    /**
     * Set the value of nome
     */
    public function setNome(?string $nome): self
    {
        $this->nome = $nome;

        return $this;
    }

    /**
     * Get the value of abreviacao
     */
    public function getAbreviacao(): ?string
    {
        return $this->abreviacao;
    }

    /**
     * Set the value of abreviacao
     */
    public function setAbreviacao(?string $abreviacao): self
    {
        $this->abreviacao = $abreviacao;

        return $this;
    }
    public function getImagem(): ?string
    {
        return $this->imagem;
    }
    public function setImagem(?string $imagem): self
    {
        $this->imagem = $imagem;

        return $this;
    }
}