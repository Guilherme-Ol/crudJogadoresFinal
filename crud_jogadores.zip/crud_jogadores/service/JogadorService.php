<?php

require_once(__DIR__ . "/../model/Jogador.php");

class JogadorService
{

    public function validar(Jogador $jogador): array
    {
        $erros = array();

        if (! $jogador->getNome())
            array_push($erros, "Informe o nome!");

        if (! $jogador->getIdade())
            array_push($erros, "Informe a idade!");

        if ($jogador->getIdade() <= 0 || $jogador->getIdade() > 60)
            array_push($erros, "Informe uma idade válida!");

        if (! $jogador->getPosicao())
            array_push($erros, "Informe a posição!");

        if (! $jogador->getNacionalidade()->getId())
            array_push($erros, "Informe a nacionalidade!");

        if (! $jogador->getClube()->getId())
            array_push($erros, "Informe o clube!");

        return $erros;
    }
}
