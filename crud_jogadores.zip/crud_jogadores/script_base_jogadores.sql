/*
Modelo de dados para o banco de dados do sistema de cadastro de jogadores de futebol.
*/

/* TABELA clubes */
CREATE TABLE clube ( 
  id int AUTO_INCREMENT NOT NULL, 
  nome varchar(70) NOT NULL,
  abreviacao varchar(3) NOT NULL,
  CONSTRAINT pk_clube PRIMARY KEY (id) 
);

/* INSERTs clubes */
INSERT INTO clube (nome, abreviacao) VALUES ('Palmeiras', 'Pal');
INSERT INTO clube (nome, abreviacao) VALUES ('Corinthians', 'Cor');
INSERT INTO clube (nome, abreviacao) VALUES ('São Paulo', 'SP');
INSERT INTO clube (nome, abreviacao) VALUES ('Santos', 'San');
INSERT INTO clube (nome, abreviacao) VALUES ('Flamengo', 'Fla');
INSERT INTO clube (nome, abreviacao) VALUES ('Fluminense', 'Flu');
INSERT INTO clube (nome, abreviacao) VALUES ('Vasco da Gama', 'Vas');
INSERT INTO clube (nome, abreviacao) VALUES ('Botafogo', 'Bot');
INSERT INTO clube (nome, abreviacao) VALUES ('Cruzeiro', 'Cru');
INSERT INTO clube (nome, abreviacao) VALUES ('Atlético Mineiro', 'Atl');
INSERT INTO clube (nome, abreviacao) VALUES ('Internacional', 'Int');
INSERT INTO clube (nome, abreviacao) VALUES ('Grêmio', 'Gre');
INSERT INTO clube (nome, abreviacao) VALUES ('Atlético Paranaense', 'Atl');
INSERT INTO clube (nome, abreviacao) VALUES ('Coritiba', 'Cor');
INSERT INTO clube (nome, abreviacao) VALUES ('Sport', 'Spo');
INSERT INTO clube (nome, abreviacao) VALUES ('Náutico', 'Nau');
INSERT INTO clube (nome, abreviacao) VALUES ('Santa Cruz', 'SC');
INSERT INTO clube (nome, abreviacao) VALUES ('América Mineiro', 'AMG');
INSERT INTO clube (nome, abreviacao) VALUES ('Bahia', 'Bah');
INSERT INTO clube (nome, abreviacao) VALUES ('Vitória', 'Vit');
INSERT INTO clube (nome, abreviacao) VALUES ('Ceará', 'Cea');


/* TABELA nacionalidade */
CREATE TABLE nacionalidade (
  id int AUTO_INCREMENT NOT NULL, 
  nome varchar(70) NOT NULL, 
  CONSTRAINT pk_nacionalidade PRIMARY KEY (id)
);

/* INSERTs nacionalidade */
INSERT INTO nacionalidade (nome) VALUES ('Alemanha');
INSERT INTO nacionalidade (nome) VALUES ('Argentina');
INSERT INTO nacionalidade (nome) VALUES ('Bélgica');
INSERT INTO nacionalidade (nome) VALUES ('Bolívia');
INSERT INTO nacionalidade (nome) VALUES ('Brasil');
INSERT INTO nacionalidade (nome) VALUES ('Canadá');
INSERT INTO nacionalidade (nome) VALUES ('Chile');
INSERT INTO nacionalidade (nome) VALUES ('China');
INSERT INTO nacionalidade (nome) VALUES ('Colômbia');
INSERT INTO nacionalidade (nome) VALUES ('Coreia do Sul');
INSERT INTO nacionalidade (nome) VALUES ('Dinamarca');
INSERT INTO nacionalidade (nome) VALUES ('Equador');
INSERT INTO nacionalidade (nome) VALUES ('Escócia');
INSERT INTO nacionalidade (nome) VALUES ('Espanha');
INSERT INTO nacionalidade (nome) VALUES ('Estados Unidos');
INSERT INTO nacionalidade (nome) VALUES ('Finlândia');
INSERT INTO nacionalidade (nome) VALUES ('França');
INSERT INTO nacionalidade (nome) VALUES ('Inglaterra');
INSERT INTO nacionalidade (nome) VALUES ('Itália');
INSERT INTO nacionalidade (nome) VALUES ('Japão');
INSERT INTO nacionalidade (nome) VALUES ('México');
INSERT INTO nacionalidade (nome) VALUES ('Noruega');
INSERT INTO nacionalidade (nome) VALUES ('Países Baixos');
INSERT INTO nacionalidade (nome) VALUES ('Paraguai');
INSERT INTO nacionalidade (nome) VALUES ('Peru');
INSERT INTO nacionalidade (nome) VALUES ('Portugal');
INSERT INTO nacionalidade (nome) VALUES ('Rússia');
INSERT INTO nacionalidade (nome) VALUES ('Suécia');
INSERT INTO nacionalidade (nome) VALUES ('Suíça');
INSERT INTO nacionalidade (nome) VALUES ('Uruguai');
INSERT INTO nacionalidade (nome) VALUES ('Venezuela');


/* TABELA jogadores */
CREATE TABLE jogadores (
  id int AUTO_INCREMENT NOT NULL, 
  nome varchar(70) NOT NULL, 
  idade int NOT NULL,
  posicao varchar(20) NOT NULL,
  id_nacionalidade int NOT NULL,
  id_clube int NOT NULL, 
  CONSTRAINT pk_jogadores PRIMARY KEY (id)
);
ALTER TABLE jogadores ADD CONSTRAINT fk_jogador_clube FOREIGN KEY (id_clube) REFERENCES clube (id);
ALTER TABLE jogadores ADD CONSTRAINT fk_jogador_nacionalidade FOREIGN KEY (id_nacionalidade) REFERENCES nacionalidade (id);