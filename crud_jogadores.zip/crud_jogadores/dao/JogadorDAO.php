<?php

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Jogador.php");

class JogadorDAO
{

    public function list()
    {
        $sql = "SELECT a.*, c.nome nome_clube, c.abreviacao abreviacao_clube, n.nome nome_nacionalidade
                FROM jogadores a
                JOIN clube c ON (c.id = a.id_clube)
                JOIN nacionalidade n ON (n.id = a.id_nacionalidade)";

        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute();

        $dados = $stm->fetchAll();
        return $this->map($dados);
    }

    public function findbyId(int $id)
    {
        $sql = "SELECT a.*, c.nome nome_clube, c.abreviacao abreviacao_clube, n.nome nome_nacionalidade
                FROM jogadores a
                JOIN clube c ON (c.id = a.id_clube)
                JOIN nacionalidade n ON (n.id = a.id_nacionalidade)
                WHERE a.id = :id";

        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->bindValue("id", $id);
        $stm->execute();

        $dados = $stm->fetchAll();
        $jogadores = $this->map($dados);

        if (! empty($jogadores))
            return $jogadores[0];
        else
            return null;
    }
    public function update(Jogador $jogador)
    {
        try {
            $sql = "UPDATE jogadores 
                    SET nome = :nome, idade = :idade, posicao = :posicao, id_nacionalidade = :id_nacionalidade, id_clube = :id_clube
                    WHERE id = :id";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue("nome", $jogador->getNome());
            $stm->bindValue("idade", $jogador->getIdade());
            $stm->bindValue("posicao", $jogador->getPosicao());
            $stm->bindValue("id_nacionalidade", $jogador->getNacionalidade()->getId());
            $stm->bindValue("id_clube", $jogador->getClube()->getId());
            $stm->bindValue("id", $jogador->getId());
            $stm->execute();
            return "";
        } catch (PDOException $e) {
            $erro = "Erro ao alterar o jogador, Tente novamente";
            if (AMB_DEV)
                $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }


    public function insert(Jogador $jogador)
    {
        try {
            $sql = "INSERT INTO jogadores (nome, idade, posicao, id_nacionalidade, id_clube)
                    VALUES (:nome, :idade, :posicao, :id_nacionalidade, :id_clube)";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->bindValue("nome", $jogador->getNome());
            $stm->bindValue("idade", $jogador->getIdade());
            $stm->bindValue("posicao", $jogador->getPosicao());
            $stm->bindValue("id_nacionalidade", $jogador->getNacionalidade()->getId());
            $stm->bindValue("id_clube", $jogador->getClube()->getId());
            $stm->execute();
            return "";
        } catch (PDOException $e) {
            $erro = "Erro ao salvar o jogador, Tente novamente";
            if (AMB_DEV)
                $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }
    public function excluir(int $id)
    {
        try {
            $sql = "DELETE FROM jogadores WHERE id = ?";

            $conn = Connection::getConnection();
            $stm = $conn->prepare($sql);
            $stm->execute([$id]);
            return "";
        } catch (PDOException $e) {
            $erro = "Erro ao excluir o jogador. Tente novamente.";
            if (AMB_DEV)
                $erro .= "<br>" . $e->getMessage();
            return $erro;
        }
    }

    private function map(array $dados)
    {
        $jogadores = array();
        foreach ($dados as $d) {
            $jogador = new Jogador();
            $jogador->setId($d['id']);
            $jogador->setNome($d["nome"]);
            $jogador->setIdade($d["idade"]);
            $jogador->setPosicao($d["posicao"]);

            $nacionalidade = new Nacionalidade();
            $nacionalidade->setId($d["id_nacionalidade"]);
            $nacionalidade->setNome($d["nome_nacionalidade"]);
            $jogador->setNacionalidade($nacionalidade);

            $clube = new Clube();
            $clube->setId($d["id_clube"]);
            $clube->setNome($d["nome_clube"]);
            $clube->setAbreviacao($d["abreviacao_clube"]);
            $jogador->setClube($clube);

            array_push($jogadores, $jogador);
        }
        return $jogadores;
    }
}
