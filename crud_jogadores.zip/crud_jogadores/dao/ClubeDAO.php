<?php

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Clube.php");

class ClubeDAO
{

    public function list()
    {
        $sql = "SELECT * FROM clube";

        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute();
        $dados = $stm->fetchAll();
        return $this->map($dados);
    }

    private function map(array $dados)
    {
        $clubes = array();

        foreach ($dados as $d) {
            $clube = new Clube();
            $clube->setId($d['id']);
            $clube->setNome($d["nome"]);
            $clube->setAbreviacao($d["abreviacao"]);

            array_push($clubes, $clube);
        }

        return $clubes;
    }
}
