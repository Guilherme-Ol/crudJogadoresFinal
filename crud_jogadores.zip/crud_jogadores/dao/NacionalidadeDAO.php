<?php

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Nacionalidade.php");

class NacionalidadeDAO
{
    public function list()
    {
        $sql = "SELECT * FROM nacionalidade";

        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute();
        $dados = $stm->fetchAll();
        return $this->map($dados);
    }
    private function map(array $dados)
    {
        $nacionalidades = array();

        foreach ($dados as $d) {
            $nacionalidade = new Nacionalidade();
            $nacionalidade->setId($d['id']);
            $nacionalidade->setNome($d["nome"]);

            array_push($nacionalidades, $nacionalidade);
        }

        return $nacionalidades;
    }
}
