<?php

//Mostrar erros do PHP
ini_set('display_errors', 1);
error_reporting(E_ALL);

//Configurar essas variáveis de acordo com o seu ambiente
define("DB_HOST", "localhost");
define("DB_NAME", "db_futebol");
define("DB_USER", "root");
define("DB_PASSWORD", "bancodedados");


//CONFIGURAÇÃO DO AMBIENTE
define("AMB_DEV", true);
//define("AMB_DEV", false);


//configuração de acesso
define("BASE_URL", "/crud_jogadores");