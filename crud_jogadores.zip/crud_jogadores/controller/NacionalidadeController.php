<?php

require_once(__DIR__ . "/../dao/NacionalidadeDAO.php");

class NacionalidadeController
{

    public function listar()
    {
        $nacionalidadeDao = new NacionalidadeDAO();
        return $nacionalidadeDao->list();
    }
}
