<?php

require_once(__DIR__ . "/../dao/ClubeDAO.php");

class ClubeController {

    public function listar() {
        $clubeDao = new ClubeDAO();
        return $clubeDao->list();
    }

}