<?php

require_once(__DIR__ . "/../dao/JogadorDAO.php");
require_once(__DIR__ . "/../service/JogadorService.php");
require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Jogador.php");


class JogadorController
{

    private JogadorDAO $jogadorDAO;
    private JogadorService $jogadorService;

    public function __construct()
    {
        $this->jogadorDAO = new JogadorDAO();
        $this->jogadorService = new JogadorService();
    }

    public function listar()
    {
        return $this->jogadorDAO->list();
    }
    public function buscarPorId(int $id)
    {
        return $this->jogadorDAO->findbyId($id);
    }
    public function alterar(Jogador $jogador)
    {
        //Validar os dados
        $erros = $this->jogadorService->validar($jogador);
        //Persistir os dados
        if (empty($erros)) {
            $erroDAO = $this->jogadorDAO->update($jogador);
            if ($erroDAO)
                array_push($erros, $erroDAO);
        }
        return $erros;
    }

    public function inserir(Jogador $jogador)
    {
        //Validar os dados
        $erros = $this->jogadorService->validar($jogador);


        //Persistir os dados
        if (empty($erros)) {
            $erroDAO = $this->jogadorDAO->insert($jogador);
            if ($erroDAO)
                array_push($erros, $erroDAO);
        }

        return $erros;
    }

    public function excluir(int $id)
    {
        return $this->jogadorDAO->excluir($id);
    }
}
