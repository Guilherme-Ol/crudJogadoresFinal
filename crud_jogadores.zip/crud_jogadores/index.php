        <?php
        require_once(__DIR__ . "/view/include/header.php");

        require_once(__DIR__ . "/view/include/menu.php");
        ?>

        <div class="row mt-3 justify-content-center">
            <div class="col-3">
                <div class="card text-center">
                    <img class="card-image-top mx-auto"
                        src="img/jogador.jpg"
                        style="max-width: 200px; height: auto;" />
                    <div class="card-body">
                        <h5 class="card-title"><strong>Jogadores</strong></h5>
                    </div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <a href="<?= BASE_URL ?>/view/jogadores/listar.php" class="card-link btn btn-secondary">
                                Listagem de jogadores</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <?php
        require_once(__DIR__ . "/view/include/footer.php");
        ?>